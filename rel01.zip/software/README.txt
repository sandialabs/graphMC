README.txt
----------

This software ('graphMC') contains the test of independence described
in Ray, Pinar and Seshadhri, "A stopping criterion for Markov chains
when generating independent random graphs", submitted to Phys. Rev. E.
It contains an implementation of the test of independence in
gibbsit/indtest.c in function indtest(int *data, int n, double *g2,
double *bic).


AUTHORS
-------

Jaideep Ray, jairay@sandia.gov, Sandia National Laboratories, Livermore, CA
Ali Pinar,   apinar@sandia.gov, Sandia National Laboratories, Livermore, CA
Cosmin Safta, csafta@sandia.gov, Sandia National Laboratories, Livermore, CA

Comments, questions and bugs to: Jaideep Ray, jairay@sandia.gov.


RELEASES
--------

Version 1.0 : September 30, 2013



CONTENTS OF THIS PACKAGE
------------------------

The contents are:

gibbsit/ 
	 Library containing indtest(), that does the test of 
	 independence. It returns Delta BIC = BIC_{independence} -
	 BIC_{first-order Markov}. Delta BIC > 0 indicates that the correlated
	 Markov model fits better than an independent samples model. This
	 function is called on an edge-by-edge basis.

	 There is also a functions, gibbsmain() that takes a time-series and
	 incrementally thins it, testing it for independence.

edge_swap/ 
	   A set of functions to take a graph and swap edges, while
	   ensuring JDD is preserved. Also functions that define and construct
	   data-structures of a graph

utils/ 
       A set of functions implementing a database of graphs

ex01/ 
      An example that checks the independence of an edge time-series,
      read in from a data file. An example output is in ex01.log.

ex02/ 
      An example that runs a JDD-preserving Markov chain and calls
      gibbsmain. gibbsmain thins the edge time-series and repeatedly calls
      indtest to check if *all* the edges in a graphical MC have become
      independent. A small graph is also included in this directory. Example
      output is in runit.log. The code can be run by simply executing runit.sh.
      It takes about 5 minutes to run.

doc/ 
     Users manual for the libraries in this package


COMPILING THIS PACKAGE (LIBRARIES AND EXAMPLES)
-----------------------------------------------

How to compile and install the library

0. In Make.incl, make sure that the compiler specs are correct. If you use a compiler
   other than gcc, you will have to change CFLAGS. If you are unsure remove everything in there and 
   keep CFLAGS blank i.e

   CFLAGS =  


1. At this level, type "make"

2. The libraries in gibbsit/ and edge_swap/ will be compiled and copied
   into libs/. Next utils/ will be compiled. ex01/ and ex02/ get compiled
   last.

   edge_swap/, gibbsit/, utils/, ex01/ and ex02/ have their own
   Makefiles. These are called by the Makefile in software/

3. Check libs/ has 3 libraries in it.

