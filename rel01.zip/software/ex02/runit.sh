/bin/rm -f runit.log
./ex02.exe -G lesmis.elist -N 100000 -S lesmis > runit.log
