#ifndef MCCONV_H_SEEN
#define MCCONV_H_SEEN

#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <math.h>

void ssort(double *x, double *y,int n,int kflag) ;
double ppnd7 ( double p, int *ifault) ;
double ppnd16( double p, int *ifault) ;


void dichot(double *data, int n, double cutpt, int *zt) ;

void mcest  (int *data, int n, double *alpha, double *beta) ;
void mctest (int *data, int n, double *g2, double *bic) ;
void indtest(int *data, int n, double *g2, double *bic) ;

void thin(int *series,int n,int kthin,int *result,int *thincnt) ;

double empquant(double *data,int n, double q, double *work) ;

void readChain(const char *fname, int chainLen, int chainDim, double *data) ;

void gibbmain(double *original, int n, double q, double r,double s,
              double epsilon, double *dwrk, int *iwrk,
              int *nmin, int *kthin, int *nburn, int *nprec, int *kmind,
              int *r15) ;

#define MATINDX(I,J,K,N,M,P) ( ( (K) * (M) + (J) ) * (N) + (I) )
#define MAX(A,B) ( ( (A) > (B) ) ? (A) : (B) )
#define MIN(A,B) ( ( (A) < (B) ) ? (A) : (B) )

#endif



