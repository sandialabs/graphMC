#include "graph.h" 


void edges2gr (char *fname, struct graph *G)
{
  int i, *to, *from, N,M;
  float x,y;
  FILE *fp;
  

  fp =fopen(fname,"r");
  fscanf(fp, "%d %d",&N,&M);
  to =(int *) malloc(sizeof(int)*2*M);
  from =(int *) malloc(sizeof(int)*2*M);
  for (i=0;i<2*M;i++) {
    fscanf(fp, "%e %e",&x, &y);
    to[i]=(int ) (x-1);
    from[i]=(int ) (y-1);
    /* printf("%d %f %d %f %d\n", i, x,to[i],y,from[i]); */
  }
  alloc_gr(G,N,M);
  
  memset (G->ptr,0,sizeof(int)*(N+1));
  for(i=0;i<2*M; i++)
    G->ptr[to[i]]++;
  for(i=0;i<N;i++)
    G->ptr[i+1]+=G->ptr[i];
  for(i=0;i<2*M;i++)
    G->ind[--G->ptr[to[i]]]=from[i];
  printf("%d \n",G->ptr[0]); 
  /*  write_graph(G);
      exit (0); */
  
}
