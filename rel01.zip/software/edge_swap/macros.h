
#include <stdlib.h>
#define myrandom(x)      ((int)(floor(drand48()*(x))))
